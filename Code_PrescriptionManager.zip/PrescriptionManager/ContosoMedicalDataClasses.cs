namespace PrescriptionManager
{
    partial class ContosoMedicalDataClassesDataContext
    {
    }
}
